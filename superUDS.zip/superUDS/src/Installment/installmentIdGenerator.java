package Installment;

import java.util.Random;

public class installmentIdGenerator {
	
	public String installmentIdGenerator() {
		
		Random num = new Random();
		int numbers;
		String prefix= "INS";
		
		for(int i=1; i<=6; i++) {
			numbers = num.nextInt(10);
			prefix = prefix+numbers;
		}
		
		return prefix;
	}

}
