package Customer;

public interface ConnectionProvider {
	
	//the required connection provider details
			String url = "jdbc:mysql://localhost:3306/udssuper";
			String user = "root";
			String pass = "M@ng@th@9093";

}
