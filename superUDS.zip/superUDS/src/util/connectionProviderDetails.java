package util;



public interface connectionProviderDetails {

	//the required connection provider details
	String connUrl = "jdbc:mysql://localhost:3306/udssuper";
	String uname = "root";
	String pwd = "M@ng@th@9093";
	
}
