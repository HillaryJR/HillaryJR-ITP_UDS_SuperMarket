package Order_Management;

public class ShoppingCartTotalAmount {
	
	private double total;
	
	

	public ShoppingCartTotalAmount() {
		super();
	}

	public ShoppingCartTotalAmount(double total) {
		super();
		this.total = total;
	}

	public double getTotal() {
		return total;
	}
	
	

}
